window.APP_CONFIG={
  appName:"مورد رزق",
  supabaseUrl:"",
  supabasePublishableKey:""
};
