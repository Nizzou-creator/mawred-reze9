const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

function toast(msg){
  const el=$("#toast"); if(!el)return;
  el.textContent=msg; el.classList.add("show");
  clearTimeout(window._toast);
  window._toast=setTimeout(()=>el.classList.remove("show"),2800);
}

$("#menuBtn")?.addEventListener("click",()=>$("#navLinks")?.classList.toggle("open"));
$$("#navLinks a").forEach(a=>a.addEventListener("click",()=>$("#navLinks")?.classList.remove("open")));

function search(term){
  if(term) $("#searchInput").value=term;
  const q=$("#searchInput").value.trim(), loc=$("#locationSelect").value;
  if(!q && !loc){toast("اكتب شنوّة تلوج ولا اختار المنطقة.");$("#smartSearch").scrollIntoView({behavior:"smooth"});return;}
  toast(`نبحثولك على ${q||"الإعلانات"}${loc?" في "+loc:""}...`);
  setTimeout(()=>$("#listings")?.scrollIntoView({behavior:"smooth"}),350);
}
$("#searchBtn")?.addEventListener("click",()=>search());
$("#searchInput")?.addEventListener("keydown",e=>{if(e.key==="Enter")search()});
$$("[data-search]").forEach(b=>b.addEventListener("click",()=>search(b.dataset.search)));

$("#searchTop")?.addEventListener("click",()=>{$("#searchInput")?.focus();window.scrollTo({top:0,behavior:"smooth"})});
$("#filterBtn")?.addEventListener("click",()=>toast("التصفية المتقدمة باش تتربط بقاعدة البيانات في المرحلة الجاية."));
$("#publishBtn")?.addEventListener("click",()=>{toast("النشر مجاني — إنشاء الحساب باش نكملولك.");$("#messages")?.scrollIntoView({behavior:"smooth"})});
$("#messagesBtn")?.addEventListener("click",()=>toast("سجّل دخولك باش تدخل للرسائل."));
$("#accountBtn")?.addEventListener("click",()=>toast("التسجيل المجاني باش يتربط بـ Supabase."));
$("#accountTop")?.addEventListener("click",()=>toast("صفحة الحساب جاهزة للربط بالتسجيل."));
$$(".talk-btn").forEach(b=>b.addEventListener("click",()=>toast("يلزمك حساب باش تتواصل مع صاحب الإعلان.")));
