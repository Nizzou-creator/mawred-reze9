const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

const cfg = window.APP_CONFIG || {};
const sb = (window.supabase && cfg.supabaseUrl && cfg.supabasePublishableKey)
  ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabasePublishableKey)
  : null;

let currentUser = null;
let currentProfile = null;
let currentListings = [];

function toast(msg){
  const el=$("#toast"); if(!el)return;
  el.textContent=msg; el.classList.add("show");
  clearTimeout(window._toast);
  window._toast=setTimeout(()=>el.classList.remove("show"),3000);
}

function esc(v){
  return String(v ?? "").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}

function openModal(html){
  $("#modalContent").innerHTML=html;
  $("#modalRoot").classList.add("open");
  $("#modalRoot").setAttribute("aria-hidden","false");
}
function closeModal(){
  $("#modalRoot").classList.remove("open");
  $("#modalRoot").setAttribute("aria-hidden","true");
}
$$("[data-close-modal]").forEach(x=>x.addEventListener("click",closeModal));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

$("#menuBtn")?.addEventListener("click",()=>$("#navLinks")?.classList.toggle("open"));
$$("#navLinks a").forEach(a=>a.addEventListener("click",()=>$("#navLinks")?.classList.remove("open")));

function search(term){
  if(term) $("#searchInput").value=term;
  const q=$("#searchInput").value.trim().toLowerCase(), loc=$("#locationSelect").value;
  const filtered=currentListings.filter(x=>{
    const text=[x.title,x.description,x.category,x.subcategory,x.governorate,x.delegation].join(" ").toLowerCase();
    return (!q || text.includes(q)) && (!loc || x.governorate===loc);
  });
  renderListings(filtered);
  if(!q && !loc){toast("اكتب شنوّة تلوج ولا اختار المنطقة.");return;}
  $("#listings")?.scrollIntoView({behavior:"smooth"});
}
$("#searchBtn")?.addEventListener("click",()=>search());
$("#searchInput")?.addEventListener("keydown",e=>{if(e.key==="Enter")search()});
$$("[data-search]").forEach(b=>b.addEventListener("click",()=>search(b.dataset.search)));
$("#searchTop")?.addEventListener("click",()=>{$("#searchInput")?.focus();window.scrollTo({top:0,behavior:"smooth"})});
$("#filterBtn")?.addEventListener("click",()=>toast("اكتب كلمة في البحث أو اختار الولاية للتصفية."));

function authForm(mode="login"){
  const login=mode==="login";
  openModal(`
    <div class="modal-kicker">${login?"مرحبا بيك 👋":"أهلا بيك في مورد رزق 🤝"}</div>
    <h2>${login?"تسجيل الدخول":"إنشاء حساب مجاني"}</h2>
    <p class="modal-note">${login?"ادخل لحسابك باش تنجم تنشر وتتواصل.":"التسجيل مجاني. اختار نوع حسابك وابدأ معانا."}</p>
    <form id="authForm" class="form-grid">
      ${login?"":`<label>الاسم الكامل<input name="full_name" required maxlength="100" placeholder="مثال: محمد علي" autocomplete="name"></label>`}
      <label>البريد الإلكتروني<input name="email" type="email" required placeholder="name@example.com" autocomplete="email"></label>
      <label>كلمة السر<input name="password" type="password" minlength="6" required placeholder="6 أحرف أو أكثر" autocomplete="${login?"current-password":"new-password"}"></label>
      ${login?"":`<label>رقم الهاتف <span class="muted">(اختياري)</span><input name="phone" inputmode="tel" maxlength="30" placeholder="مثال: 20 000 000"></label>
      <label>الولاية <span class="muted">(اختياري)</span><select name="governorate"><option value="">اختر الولاية</option><option>تونس</option><option>أريانة</option><option>بن عروس</option><option>منوبة</option><option>نابل</option><option>زغوان</option><option>بنزرت</option><option>باجة</option><option>جندوبة</option><option>الكاف</option><option>سليانة</option><option>سوسة</option><option>المنستير</option><option>المهدية</option><option>صفاقس</option><option>القيروان</option><option>القصرين</option><option>سيدي بوزيد</option><option>قابس</option><option>مدنين</option><option>تطاوين</option><option>قبلي</option><option>توزر</option><option>قفصة</option></select></label>
      <label>شنوّة نوع حسابك<select name="account_type"><option value="customer">حريف / طالب خدمة</option><option value="provider">مقدّم خدمة</option><option value="seller">بائع / صاحب سلعة</option></select></label>`}
      <button class="primary-btn" type="submit">${login?"دخول":"إنشاء الحساب"}</button>
    </form>
    <button class="switch-auth" id="switchAuth" type="button">${login?"ما عندكش حساب؟ أنشئ حساب مجاني":"عندك حساب؟ سجّل الدخول"}</button>
  `);
  $("#authForm").addEventListener("submit",async e=>{
    e.preventDefault();
    if(!sb){toast("إعداد Supabase ناقص.");return;}
    const fd=new FormData(e.target), email=String(fd.get("email")||"").trim(), password=String(fd.get("password")||"");
    const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="جاري المعالجة...";
    try{
      if(login){
        const {error}=await sb.auth.signInWithPassword({email,password});
        if(error) throw error;
        toast("تم تسجيل الدخول بنجاح ❤️"); closeModal();
      }else{
        const metadata={
          full_name:String(fd.get("full_name")||"").trim(),
          account_type:String(fd.get("account_type")||"customer"),
          phone:String(fd.get("phone")||"").trim()||null,
          governorate:String(fd.get("governorate")||"").trim()||null
        };
        const {data,error}=await sb.auth.signUp({email,password,options:{data:metadata}});
        if(error) throw error;
        if(data.session){
          currentUser=data.session.user;
          await loadProfile(); updateAccountButton();
          toast("الحساب تخلق بنجاح ❤️"); closeModal();
        }else{
          openModal(`<div class="success-icon">✉️</div><h2>الحساب تخلق بنجاح</h2><p class="modal-note">إذا كان تأكيد البريد الإلكتروني مفعّل، ثبت إيميلك من الرسالة اللي بعثهالك Supabase، وبعدها ارجع وسجّل الدخول.</p><button class="primary-btn" id="backLogin" type="button">رجوع لتسجيل الدخول</button>`);
          $("#backLogin").onclick=()=>authForm("login");
        }
      }
    }catch(err){toast(err.message||"صار خطأ، حاول مرة أخرى.");btn.disabled=false;btn.textContent=login?"دخول":"إنشاء الحساب";}
  });
  $("#switchAuth").onclick=()=>authForm(login?"signup":"login");
}

async function loadProfile(){
  if(!sb||!currentUser){currentProfile=null;return;}
  const {data}=await sb.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
  currentProfile=data||null;
}

function updateAccountButton(){
  const b=$("#accountTop"); if(!b)return;
  if(currentUser){b.textContent=currentProfile?.full_name||"حسابي";} else b.textContent="تسجيل الدخول";
}

async function handleAccount(){
  if(!currentUser){authForm("login");return;}
  openModal(`<div class="modal-kicker">حسابك في مورد رزق</div><h2>${esc(currentProfile?.full_name||"مستخدم")}</h2><p class="modal-note">${esc(currentUser.email||"")}</p><div class="account-box"><b>${currentProfile?.account_type==="provider"?"مقدّم خدمة":currentProfile?.account_type==="seller"?"بائع / صاحب سلعة":"حريف / طالب خدمة"}</b><span>${esc(currentProfile?.governorate||"الموقع غير محدد")}</span>${currentProfile?.phone?`<span>📱 ${esc(currentProfile.phone)}</span>`:""}</div><button class="primary-btn" id="myPublish">➕ نشر إعلان</button><button class="secondary-btn" id="logoutBtn">تسجيل الخروج</button>`);
  $("#myPublish").onclick=()=>publishForm();
  $("#logoutBtn").onclick=async()=>{await sb.auth.signOut();closeModal();toast("خرجت من الحساب.");};
}
$("#accountTop")?.addEventListener("click",handleAccount);
$("#accountBtn")?.addEventListener("click",handleAccount);

function publishForm(){
  if(!currentUser){closeModal();authForm("login");return;}
  openModal(`<div class="modal-kicker">إعلان جديد 📣</div><h2>انشر خدمتك ولا سلعتك</h2><p class="modal-note">النشر الأساسي مجاني. الإعلان يظهر بعد المراجعة والموافقة.</p>
    <form id="publishForm" class="form-grid">
      <label>نوع الإعلان<select name="listing_type"><option value="service">خدمة</option><option value="product">منتج</option></select></label>
      <label>العنوان<input name="title" required maxlength="120" placeholder="مثال: كهربائي منازل"></label>
      <label>الوصف<textarea name="description" required maxlength="1000" placeholder="اشرح خدمتك أو السلعة..."></textarea></label>
      <label>التصنيف<input name="category" placeholder="مثال: كهرباء"></label>
      <label>السعر<input name="price" type="number" min="0" step="0.001" placeholder="اختياري"></label>
      <label>الولاية<select name="governorate"><option value="">اختر الولاية</option><option>تونس</option><option>سوسة</option><option>صفاقس</option><option>المنستير</option><option>نابل</option><option>بنزرت</option><option>قابس</option><option>مدنين</option></select></label>
      <label>المعتمدية<input name="delegation" placeholder="اختياري"></label>
      <label>رقم الهاتف<input name="phone" inputmode="tel" placeholder="اختياري"></label>
      <button class="primary-btn" type="submit">نشر الإعلان</button>
    </form>`);
  $("#publishForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(e.target), payload={owner_id:currentUser.id,listing_type:fd.get("listing_type"),title:fd.get("title"),description:fd.get("description"),category:fd.get("category")||null,price:fd.get("price")?Number(fd.get("price")):null,governorate:fd.get("governorate")||null,delegation:fd.get("delegation")||null,phone:fd.get("phone")||currentProfile?.phone||null,status:"pending"};
    const btn=e.target.querySelector("button[type=submit]");btn.disabled=true;btn.textContent="جاري النشر...";
    const {error}=await sb.from("listings").insert(payload);
    if(error){toast(error.message||"تعذر نشر الإعلان.");btn.disabled=false;btn.textContent="نشر الإعلان";return;}
    closeModal();toast("إعلانك تبعث للمراجعة بنجاح ❤️");
  });
}
$("#publishBtn")?.addEventListener("click",publishForm);
$("#messagesBtn")?.addEventListener("click",()=>{if(!currentUser)authForm("login");else toast("الرسائل المباشرة نكملوها في المرحلة القادمة.");});

function renderListings(items){
  const grid=$(".listing-grid"); if(!grid)return;
  if(!items.length){grid.innerHTML=`<div class="empty-state"><div>🔎</div><h3>ما لقيناش إعلانات منشورة</h3><p>جرّب كلمة أخرى أو ولاية أخرى. الإعلانات الجديدة تظهر بعد الموافقة.</p></div>`;return;}
  grid.innerHTML=items.map(x=>{
    const initials=(x.title||"م").trim().charAt(0);
    const tag=x.listing_type==="product"?"منتج":"خدمة";
    const price=x.price!=null?`${Number(x.price).toLocaleString("fr-TN")} د.ت`:(x.price_label||"السعر حسب الطلب");
    return `<article class="listing" data-id="${esc(x.id)}"><div class="listing-top"><div class="avatar purple">${esc(initials)}</div>${x.is_featured?'<span class="verified">★ مميّز</span>':''}</div><span class="tag">${tag}</span><h3>${esc(x.title)}</h3><p>${esc(x.description).slice(0,150)}</p><div class="listing-meta"><span>📍 ${esc(x.governorate||"تونس")}</span><span>💰 ${esc(price)}</span></div><button class="talk-btn" data-owner="${esc(x.owner_id)}" data-listing="${esc(x.id)}">💬 تواصل</button></article>`;
  }).join("");
  $$(".talk-btn").forEach(b=>b.addEventListener("click",()=>startConversation(b.dataset.listing,b.dataset.owner)));
}

async function loadListings(){
  if(!sb)return;
  const {data,error}=await sb.from("listings").select("id,owner_id,listing_type,title,description,category,subcategory,price,price_label,governorate,delegation,is_featured,created_at").eq("status","approved").order("is_featured",{ascending:false}).order("created_at",{ascending:false}).limit(30);
  if(error){console.error(error);toast("تعذر تحميل الإعلانات حاليا.");return;}
  currentListings=data||[];renderListings(currentListings);
}

async function startConversation(listingId,ownerId){
  if(!currentUser){authForm("login");return;}
  if(currentUser.id===ownerId){toast("هذا إعلانك إنت.");return;}
  const {data,error}=await sb.from("conversations").select("id").eq("listing_id",listingId).eq("customer_id",currentUser.id).eq("owner_id",ownerId).maybeSingle();
  if(error){toast("تعذر فتح المحادثة.");return;}
  if(data){openMessageBox(data.id);return;}
  const created=await sb.from("conversations").insert({listing_id:listingId,customer_id:currentUser.id,owner_id:ownerId}).select("id").single();
  if(created.error){toast(created.error.message);return;}
  openMessageBox(created.data.id);
}

async function openMessageBox(conversationId){
  openModal(`<div class="modal-kicker">رسالة جديدة 💬</div><h2>تواصل مع صاحب الإعلان</h2><div id="messageHistory" class="message-history"><span>جاري التحميل...</span></div><form id="messageForm" class="message-form"><input name="message" required maxlength="1000" placeholder="اكتب رسالتك..."><button class="primary-btn" type="submit">إرسال</button></form>`);
  const load=async()=>{const {data}=await sb.from("messages").select("id,sender_id,message,created_at").eq("conversation_id",conversationId).order("created_at",{ascending:true});$("#messageHistory").innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender_id===currentUser.id?"mine":"theirs"}">${esc(m.message)}</div>`).join("")||"<span>ابدأ المحادثة 👋</span>";};
  await load();
  $("#messageForm").addEventListener("submit",async e=>{e.preventDefault();const fd=new FormData(e.target),message=fd.get("message");const {error}=await sb.from("messages").insert({conversation_id:conversationId,sender_id:currentUser.id,message});if(error){toast(error.message);return;}e.target.reset();await load();});
}

async function boot(){
  if(!sb){toast("Supabase غير مهيّأ في النسخة الحالية.");return;}
  const {data}=await sb.auth.getSession();
  currentUser=data.session?.user||null;
  await loadProfile();updateAccountButton();await loadListings();
  sb.auth.onAuthStateChange(async (_event,session)=>{currentUser=session?.user||null;await loadProfile();updateAccountButton();if(_event==="SIGNED_IN")loadListings();});
}
boot();
