const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

const cfg = window.APP_CONFIG || {};
const sb = (window.supabase && cfg.supabaseUrl && cfg.supabasePublishableKey)
  ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabasePublishableKey)
  : null;

let currentUser = null;
let currentProfile = null;
let currentListings = [];
let isAdmin = false;

function toast(msg){
  const el=$("#toast"); if(!el)return;
  el.textContent=msg; el.classList.add("show");
  clearTimeout(window._toast);
  window._toast=setTimeout(()=>el.classList.remove("show"),3000);
}

function esc(v){
  return String(v ?? "").replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}

function openModal(html){
  $("#modalContent").innerHTML=html;
  $("#modalRoot").classList.add("open");
  $("#modalRoot").setAttribute("aria-hidden","false");
}
function closeModal(){
  $("#modalRoot").classList.remove("open");
  $("#modalRoot").setAttribute("aria-hidden","true");
}
$$("[data-close-modal]").forEach(x=>x.addEventListener("click",closeModal));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

$("#menuBtn")?.addEventListener("click",()=>$("#navLinks")?.classList.toggle("open"));
$$("#navLinks a").forEach(a=>a.addEventListener("click",()=>$("#navLinks")?.classList.remove("open")));

function search(term){
  if(term) $("#searchInput").value=term;
  const q=$("#searchInput").value.trim().toLowerCase(), loc=$("#locationSelect").value;
  const filtered=currentListings.filter(x=>{
    const text=[x.title,x.description,x.category,x.subcategory,x.governorate,x.delegation].join(" ").toLowerCase();
    return (!q || text.includes(q)) && (!loc || x.governorate===loc);
  });
  renderListings(filtered);
  if(!q && !loc){toast("اكتب شنوّة تلوج ولا اختار المنطقة.");return;}
  $("#listings")?.scrollIntoView({behavior:"smooth"});
}
$("#searchBtn")?.addEventListener("click",()=>search());
$("#searchInput")?.addEventListener("keydown",e=>{if(e.key==="Enter")search()});
$$("[data-search]").forEach(b=>b.addEventListener("click",()=>search(b.dataset.search)));
$("#searchTop")?.addEventListener("click",()=>{$("#searchInput")?.focus();window.scrollTo({top:0,behavior:"smooth"})});
$("#filterBtn")?.addEventListener("click",()=>toast("اكتب كلمة في البحث أو اختار الولاية للتصفية."));

function authForm(mode="login"){
  const login=mode==="login";
  openModal(`
    <div class="modal-kicker">${login?"مرحبا بيك 👋":"أهلا بيك في مورد رزق 🤝"}</div>
    <h2>${login?"تسجيل الدخول":"إنشاء حساب مجاني"}</h2>
    <p class="modal-note">${login?"ادخل لحسابك باش تنجم تنشر وتتواصل.":"التسجيل مجاني. اختار نوع حسابك وابدأ معانا."}</p>
    <form id="authForm" class="form-grid">
      ${login?"":`<label>الاسم الكامل<input name="full_name" required maxlength="100" placeholder="مثال: محمد علي" autocomplete="name"></label>`}
      <label>البريد الإلكتروني<input name="email" type="email" required placeholder="name@example.com" autocomplete="email"></label>
      <label>كلمة السر<input name="password" type="password" minlength="6" required placeholder="6 أحرف أو أكثر" autocomplete="${login?"current-password":"new-password"}"></label>
      ${login?"":`<label>رقم الهاتف <span class="muted">(اختياري)</span><input name="phone" inputmode="tel" maxlength="30" placeholder="مثال: 20 000 000"></label>
      <label>الولاية <span class="muted">(اختياري)</span><select name="governorate"><option value="">اختر الولاية</option><option>تونس</option><option>أريانة</option><option>بن عروس</option><option>منوبة</option><option>نابل</option><option>زغوان</option><option>بنزرت</option><option>باجة</option><option>جندوبة</option><option>الكاف</option><option>سليانة</option><option>سوسة</option><option>المنستير</option><option>المهدية</option><option>صفاقس</option><option>القيروان</option><option>القصرين</option><option>سيدي بوزيد</option><option>قابس</option><option>مدنين</option><option>تطاوين</option><option>قبلي</option><option>توزر</option><option>قفصة</option></select></label>
      <label>شنوّة نوع حسابك<select name="account_type"><option value="customer">حريف / طالب خدمة</option><option value="provider">مقدّم خدمة</option><option value="seller">بائع / صاحب سلعة</option></select></label>`}
      <button class="primary-btn" type="submit">${login?"دخول":"إنشاء الحساب"}</button>
    </form>
    <button class="switch-auth" id="switchAuth" type="button">${login?"ما عندكش حساب؟ أنشئ حساب مجاني":"عندك حساب؟ سجّل الدخول"}</button>
  `);
  $("#authForm").addEventListener("submit",async e=>{
    e.preventDefault();
    if(!sb){toast("إعداد Supabase ناقص.");return;}
    const fd=new FormData(e.target), email=String(fd.get("email")||"").trim(), password=String(fd.get("password")||"");
    const btn=e.target.querySelector("button[type=submit]"); btn.disabled=true; btn.textContent="جاري المعالجة...";
    try{
      if(login){
        const {error}=await sb.auth.signInWithPassword({email,password});
        if(error) throw error;
        toast("تم تسجيل الدخول بنجاح ❤️"); closeModal();
      }else{
        const metadata={
          full_name:String(fd.get("full_name")||"").trim(),
          account_type:String(fd.get("account_type")||"customer"),
          phone:String(fd.get("phone")||"").trim()||null,
          governorate:String(fd.get("governorate")||"").trim()||null
        };
        const {data,error}=await sb.auth.signUp({email,password,options:{data:metadata}});
        if(error) throw error;
        if(data.session){
          currentUser=data.session.user;
          await loadProfile(); updateAccountButton();
          toast("الحساب تخلق بنجاح ❤️"); closeModal();
        }else{
          openModal(`<div class="success-icon">✉️</div><h2>الحساب تخلق بنجاح</h2><p class="modal-note">إذا كان تأكيد البريد الإلكتروني مفعّل، ثبت إيميلك من الرسالة اللي بعثهالك Supabase، وبعدها ارجع وسجّل الدخول.</p><button class="primary-btn" id="backLogin" type="button">رجوع لتسجيل الدخول</button>`);
          $("#backLogin").onclick=()=>authForm("login");
        }
      }
    }catch(err){toast(err.message||"صار خطأ، حاول مرة أخرى.");btn.disabled=false;btn.textContent=login?"دخول":"إنشاء الحساب";}
  });
  $("#switchAuth").onclick=()=>authForm(login?"signup":"login");
}

async function loadProfile(){
  if(!sb||!currentUser){currentProfile=null;return;}
  const {data}=await sb.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
  currentProfile=data||null;
}


async function loadAdminStatus(){
  isAdmin = false;
  if(!sb || !currentUser) return false;

  // Primary check: Supabase admins table.
  const {data,error} = await sb.from("admins")
    .select("user_id")
    .eq("user_id",currentUser.id)
    .maybeSingle();
  if(!error && data) { isAdmin = true; return true; }

  // Fallback for the current MREMMA admin account if RLS blocks the read.
  // Authentication still comes from Supabase; this only restores the admin UI.
  const adminEmails = ["nizarajala3@gmail.com"];
  if(adminEmails.includes(String(currentUser.email||"").toLowerCase())) isAdmin = true;
  return isAdmin;
}

function updateAccountButton(){
  const b=$("#accountTop"); if(!b)return;
  if(currentUser){b.textContent=currentProfile?.full_name||"حسابي";} else b.textContent="تسجيل الدخول";
}

async function handleAccount(){
  if(!currentUser){authForm("login");return;}
  await loadAdminStatus();
  const {count}=await sb.from("listings").select("id",{count:"exact",head:true}).eq("owner_id",currentUser.id);
  const myCount=Number(count||0);
  openModal(`<div class="modal-kicker">حسابك في مورد رزق</div>
    <h2>${esc(currentProfile?.full_name||"مستخدم")}</h2>
    <p class="modal-note">${esc(currentUser.email||"")}</p>
    <div class="account-box">
      <b>${currentProfile?.account_type==="provider"?"مقدّم خدمة":currentProfile?.account_type==="seller"?"بائع / صاحب سلعة":"حريف / طالب خدمة"}</b>
      <span>${esc(currentProfile?.governorate||"الموقع غير محدد")}</span>
      ${currentProfile?.phone?`<span>📱 ${esc(currentProfile.phone)}</span>`:""}
    </div>
    <button class="primary-btn" id="myListingsBtn">📋 إعلاناتي (${myCount})</button>
    ${isAdmin?`<button class="primary-btn admin-access-btn" id="adminBtn">🛡️ لوحة الإدارة</button>`:""}
    <button class="secondary-btn" id="myPublish">➕ نشر إعلان</button>
    <button class="secondary-btn" id="logoutBtn">تسجيل الخروج</button>`);
  $("#myListingsBtn").onclick=()=>myListings();
  $("#adminBtn")?.addEventListener("click",()=>adminPanel("overview"));
  $("#myPublish").onclick=()=>publishForm();
  $("#logoutBtn").onclick=async()=>{await sb.auth.signOut();closeModal();toast("خرجت من الحساب.");};
}

window.handleAccount = handleAccount;
$("#accountTop")?.addEventListener("click",handleAccount);
$("#accountBtn")?.addEventListener("click",handleAccount);

async function myListings(){
  if(!currentUser){authForm("login");return;}
  const [{data,error},{data:promos}] = await Promise.all([
    sb.from("listings").select("id,listing_type,title,description,category,price,price_label,governorate,delegation,phone,status,is_featured,featured_until,created_at").eq("owner_id",currentUser.id).order("created_at",{ascending:false}),
    sb.from("promotions").select("id,listing_id,status,price,ends_at,created_at").eq("user_id",currentUser.id).order("created_at",{ascending:false})
  ]);
  if(error){toast(error.message||"تعذر تحميل إعلاناتك.");return;}

  const promoMap={};
  (promos||[]).forEach(p=>{
    if(!promoMap[p.listing_id]) promoMap[p.listing_id]=p;
    else if(p.status==="pending" || p.status==="active") promoMap[p.listing_id]=p;
  });

  const items=data||[];
  openModal(`<div class="modal-kicker">لوحة إعلاناتك 📋</div><h2>إعلاناتي</h2><p class="modal-note">تنجم تعدّل ولا تحذف أي إعلان نشرتو من حسابك، وتطلب تمييز الإعلان من هنا.</p><button class="primary-btn" id="myPublishFromList">➕ نشر إعلان جديد</button><div class="my-listings-list">${items.length?items.map(x=>{
    const price=x.price!=null?`${Number(x.price).toLocaleString("fr-TN")} د.ت`:(x.price_label||"السعر حسب الطلب");
    const status=x.status==="approved"?"منشور":x.status==="pending"?"قيد المراجعة":x.status==="rejected"?"مرفوض":x.status==="paused"?"متوقف":"منتهي";
    const promo=promoMap[x.id];
    let featureLabel="⭐ تمييز الإعلان", featureClass="secondary-btn", featureDisabled="";
    if(x.is_featured){
      featureLabel="⭐ مميّز";
      featureDisabled="disabled";
      featureClass="secondary-btn feature-active-btn";
    }else if(promo?.status==="pending"){
      featureLabel="⏳ طلب التمييز قيد المراجعة";
      featureDisabled="disabled";
      featureClass="secondary-btn feature-pending-btn";
    }else if(promo?.status==="cancelled"){
      featureLabel="⭐ إعادة طلب التمييز";
    }
    return `<div class="my-listing-item"><div class="my-listing-head"><span class="tag">${x.listing_type==="product"?"منتج":"خدمة"}</span><span class="my-status">${status}</span></div><h3>${esc(x.title)}</h3><p>${esc((x.description||"").slice(0,120))}</p><div class="listing-meta"><span>📍 ${esc(x.governorate||"غير محدد")}</span><span>💰 ${esc(price)}</span></div>${promo?.status==="active"&&!x.is_featured?`<div class="promotion-note">⭐ طلب التمييز مفعّل</div>`:""}<div class="my-listing-actions"><button type="button" class="secondary-btn my-edit-btn" data-id="${esc(x.id)}">✏️ تعديل</button><button type="button" class="${featureClass} my-feature-btn" data-id="${esc(x.id)}" ${featureDisabled}>${featureLabel}</button><button type="button" class="danger-btn my-delete-btn" data-id="${esc(x.id)}">🗑️ حذف</button></div></div>`;
  }).join(""):"<div class=\"empty-state\"><div>📭</div><h3>ما عندك حتى إعلان</h3><p>انشر أول إعلان متاعك وابدأ تلقى حرفاء.</p></div>"}</div>`);
  $("#myPublishFromList").onclick=()=>publishForm();
  $$(".my-edit-btn").forEach(b=>b.addEventListener("click",()=>editListing(b.dataset.id)));
  $$(".my-feature-btn").forEach(b=>b.addEventListener("click",()=>requestFeatured(b.dataset.id)));
  $$(".my-delete-btn").forEach(b=>b.addEventListener("click",()=>deleteListing(b.dataset.id)));
}
async function requestFeatured(id){
  if(!currentUser){authForm("login");return;}
  const listing=(await sb.from("listings").select("id,title,is_featured").eq("id",id).eq("owner_id",currentUser.id).single()).data;
  if(!listing){toast("الإعلان هذا ما عادش موجود.");return;}
  if(listing.is_featured){toast("الإعلان هذا مميّز بالفعل ⭐");return;}
  const existing=await sb.from("promotions").select("id,status,ends_at").eq("listing_id",id).eq("user_id",currentUser.id).in("status",["pending","active"]).limit(1);
  if(existing.error){toast(existing.error.message||"تعذر التثبت من طلب التمييز.");return;}
  if(existing.data?.length){toast(existing.data[0].status==="pending"?"عندك طلب تمييز قيد المراجعة ⏳":"الإعلان هذا مميّز بالفعل ⭐");return;}
  openModal(`<div class="modal-kicker">تمييز الإعلان ⭐</div><h2>${esc(listing.title)}</h2><p class="modal-note">اختار المدة. بعد الإرسال، الطلب يوصل للإدارة للموافقة.</p><div class="promotion-plans"><button type="button" class="promotion-plan" data-days="7" data-price="3"><b>⭐ 7 أيام</b><span>3 د.ت</span></button><button type="button" class="promotion-plan" data-days="30" data-price="10"><b>⭐ 30 يوم</b><span>10 د.ت</span></button></div><p id="promotionHint" class="rating-hint">اختار العرض المناسب.</p><button class="primary-btn" id="submitPromotion" type="button" disabled>إرسال طلب التمييز</button>`);
  let days=0,price=0;
  $$(".promotion-plan").forEach(b=>b.addEventListener("click",()=>{days=Number(b.dataset.days);price=Number(b.dataset.price);$$(".promotion-plan").forEach(x=>x.classList.toggle("selected",x===b));$("#promotionHint").textContent=`اخترت ${days} يوم — ${price} د.ت. الدفع يتم بعد اعتماد طريقة الدفع.`;$("#submitPromotion").disabled=false;}));
  $("#submitPromotion").onclick=async()=>{
    if(!days)return; const btn=$("#submitPromotion");btn.disabled=true;btn.textContent="جاري إرسال الطلب...";
    const {error}=await sb.from("promotions").insert({user_id:currentUser.id,listing_id:id,promotion_type:"featured",price,status:"pending",ends_at:new Date(Date.now()+days*86400000).toISOString()});
    if(error){toast(error.code==="23505"?"عندك طلب موجود بالفعل.":(error.message||"تعذر إرسال الطلب."));btn.disabled=false;btn.textContent="إرسال طلب التمييز";return;}
    closeModal();toast("تم إرسال طلب التمييز للإدارة ⏳⭐");
  };
}

async function editListing(id){
  const {data,error}=await sb.from("listings").select("id,listing_type,title,description,category,price,governorate,delegation,phone").eq("id",id).eq("owner_id",currentUser.id).single();
  if(error||!data){toast("الإعلان هذا ما عادش موجود أو ما عندكش صلاحية تعدلو.");return;}
  openModal(`<div class="modal-kicker">تعديل الإعلان ✏️</div><h2>عدّل إعلانك</h2><form id="editListingForm" class="form-grid">
    <label>نوع الإعلان<select name="listing_type"><option value="service" ${data.listing_type==="service"?"selected":""}>خدمة</option><option value="product" ${data.listing_type==="product"?"selected":""}>منتج</option></select></label>
    <label>العنوان<input name="title" required maxlength="120" value="${esc(data.title||"")}"></label>
    <label>الوصف<textarea name="description" required maxlength="1000">${esc(data.description||"")}</textarea></label>
    <label>التصنيف<input name="category" value="${esc(data.category||"")}" placeholder="مثال: كهرباء"></label>
    <label>السعر<input name="price" type="number" min="0" step="0.001" value="${data.price??""}" placeholder="اختياري"></label>
    <label>الولاية<select name="governorate"><option value="">اختر الولاية</option>${["تونس","سوسة","صفاقس","المنستير","نابل","بنزرت","قابس","مدنين"].map(g=>`<option ${data.governorate===g?"selected":""}>${g}</option>`).join("")}</select></label>
    <label>المعتمدية<input name="delegation" value="${esc(data.delegation||"")}" placeholder="اختياري"></label>
    <label>رقم الهاتف<input name="phone" inputmode="tel" value="${esc(data.phone||"")}" placeholder="اختياري"></label>
    <button class="primary-btn" type="submit">حفظ التعديلات</button>
  </form>`);
  $("#editListingForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(e.target);
    const payload={listing_type:fd.get("listing_type"),title:fd.get("title"),description:fd.get("description"),category:fd.get("category")||null,price:fd.get("price")?Number(fd.get("price")):null,governorate:fd.get("governorate")||null,delegation:fd.get("delegation")||null,phone:fd.get("phone")||null};
    const btn=e.target.querySelector("button[type=submit]");btn.disabled=true;btn.textContent="جاري الحفظ...";
    const r=await sb.from("listings").update(payload).eq("id",id).eq("owner_id",currentUser.id);
    if(r.error){toast(r.error.message||"تعذر تعديل الإعلان.");btn.disabled=false;btn.textContent="حفظ التعديلات";return;}
    toast("تم تعديل الإعلان بنجاح ❤️");
    await loadListings();
    myListings();
  });
}

async function deleteListing(id){
  if(!currentUser)return;
  const ok=confirm("متأكد تحب تحذف الإعلان نهائيا؟");
  if(!ok)return;
  const {error}=await sb.from("listings").delete().eq("id",id).eq("owner_id",currentUser.id);
  if(error){toast(error.message||"تعذر حذف الإعلان.");return;}
  toast("تم حذف الإعلان بنجاح 🗑️");
  await loadListings();
  myListings();
}

$('#myListingsNav')?.addEventListener('click',e=>{e.preventDefault();if(!currentUser)authForm('login');else myListings();});

function publishForm(){
  if(!currentUser){closeModal();authForm("login");return;}
  openModal(`<div class="modal-kicker">إعلان جديد 📣</div><h2>انشر خدمتك ولا سلعتك</h2><p class="modal-note">النشر الأساسي مجاني. الإعلان يظهر مباشرة بعد النشر.</p>
    <form id="publishForm" class="form-grid">
      <label>نوع الإعلان<select name="listing_type"><option value="service">خدمة</option><option value="product">منتج</option></select></label>
      <label>العنوان<input name="title" required maxlength="120" placeholder="مثال: كهربائي منازل"></label>
      <label>الوصف<textarea name="description" required maxlength="1000" placeholder="اشرح خدمتك أو السلعة..."></textarea></label>
      <label>التصنيف<input name="category" placeholder="مثال: كهرباء"></label>
      <label>السعر<input name="price" type="number" min="0" step="0.001" placeholder="اختياري"></label>
      <label>الولاية<select name="governorate"><option value="">اختر الولاية</option><option>تونس</option><option>سوسة</option><option>صفاقس</option><option>المنستير</option><option>نابل</option><option>بنزرت</option><option>قابس</option><option>مدنين</option></select></label>
      <label>المعتمدية<input name="delegation" placeholder="اختياري"></label>
      <label>رقم الهاتف<input name="phone" inputmode="tel" placeholder="اختياري"></label>
      <button class="primary-btn" type="submit">نشر الإعلان</button>
    </form>`);
  $("#publishForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(e.target), payload={owner_id:currentUser.id,listing_type:fd.get("listing_type"),title:fd.get("title"),description:fd.get("description"),category:fd.get("category")||null,price:fd.get("price")?Number(fd.get("price")):null,governorate:fd.get("governorate")||null,delegation:fd.get("delegation")||null,phone:fd.get("phone")||currentProfile?.phone||null,status:"approved"};
    const btn=e.target.querySelector("button[type=submit]");btn.disabled=true;btn.textContent="جاري النشر...";
    const {error}=await sb.from("listings").insert(payload);
    if(error){toast(error.message||"تعذر نشر الإعلان.");btn.disabled=false;btn.textContent="نشر الإعلان";return;}
    closeModal();toast("تم نشر إعلانك بنجاح ❤️");await loadListings();
  });
}
$("#publishBtn")?.addEventListener("click",publishForm);
$("#messagesBtn")?.addEventListener("click",()=>{if(!currentUser)authForm("login");else messagesInbox();});
$("#notificationsBtn")?.addEventListener("click",notificationsInbox);

async function loadNotificationBadge(){
  if(!sb||!currentUser)return;
  const {count,error}=await sb.from("notifications").select("id",{count:"exact",head:true}).eq("user_id",currentUser.id).eq("is_read",false);
  if(error)return;
  const b=$("#notificationBadge"); if(!b)return;
  const n=Number(count||0); b.textContent=n>99?"99+":String(n); b.hidden=n===0;
}

async function notificationsInbox(){
  if(!currentUser){authForm("login");return;}
  const {data,error}=await sb.from("notifications").select("id,type,title,body,link,is_read,created_at").eq("user_id",currentUser.id).order("created_at",{ascending:false}).limit(30);
  if(error){toast(error.message||"تعذر تحميل الإشعارات.");return;}
  const items=data||[];
  openModal(`<div class="modal-kicker">الإشعارات 🔔</div><h2>إشعاراتك</h2><p class="modal-note">اضغط على رسالة باش تفتح المحادثة مباشرة.</p><div class="notification-list">${items.length?items.map(n=>`<button type="button" class="notification-item ${n.is_read?"read":"unread"}" data-id="${esc(n.id)}" data-link="${esc(n.link||"")}"><div class="notification-icon">${n.type==="message"?"💬":"🔔"}</div><div class="notification-content"><b>${esc(n.title||"إشعار")}</b><p>${esc(n.body||"")}</p><small>${new Date(n.created_at).toLocaleString("fr-TN")}</small></div></button>`).join(""):"<div class=\"empty-state\"><div>🔔</div><h3>ما عندك حتى إشعار</h3><p>كي توصلك رسالة ولا تنبيه، يظهر لهنا.</p></div>"}</div>`);

  // Handle notification taps with event delegation so the handler keeps working
  // even when the modal content is recreated.
  const list=$(".notification-list");
  if(list){
    list.onclick=async e=>{
      const item=e.target.closest(".notification-item");
      if(!item)return;
      const id=item.dataset.id||"";
      const link=item.dataset.link||"";
      if(id){await sb.from("notifications").update({is_read:true}).eq("id",id).eq("user_id",currentUser.id);}
      await loadNotificationBadge();
      if(link){
        closeModal();
        setTimeout(()=>openMessageBox(link),50);
      }else{
        toast("الإشعار هذا ما عندوش محادثة مرتبطة.");
      }
    };
  }
}

async function messagesInbox(){
  if(!currentUser){authForm("login");return;}
  const {data,error}=await sb.from("conversations").select("id,listing_id,customer_id,owner_id,updated_at").or(`customer_id.eq.${currentUser.id},owner_id.eq.${currentUser.id}`).order("updated_at",{ascending:false});
  if(error){toast(error.message||"تعذر تحميل الرسائل.");return;}
  const conversations=data||[];
  if(!conversations.length){
    openModal(`<div class="modal-kicker">الرسائل 💬</div><h2>ما عندكش رسائل تو</h2><p class="modal-note">كي تضغط «تواصل» على أي إعلان، المحادثة متاعك تظهر لهنا.</p>`);
    return;
  }
  const ids=conversations.map(c=>c.listing_id).filter(Boolean);
  const listingMap={};
  if(ids.length){
    const r=await sb.from("listings").select("id,title").in("id",ids);
    (r.data||[]).forEach(x=>listingMap[x.id]=x.title);
  }
  const convIds=conversations.map(c=>c.id);
  const mr=await sb.from("messages").select("conversation_id,sender_id,message,created_at").in("conversation_id",convIds).order("created_at",{ascending:false});
  const lastMap={};
  (mr.data||[]).forEach(m=>{if(!lastMap[m.conversation_id])lastMap[m.conversation_id]=m;});
  openModal(`<div class="modal-kicker">الرسائل 💬</div><h2>محادثاتك</h2><p class="modal-note">اضغط على محادثة باش تكمل الكلام.</p><div class="conversation-list">${conversations.map(c=>{const m=lastMap[c.id];const other=c.customer_id===currentUser.id?"صاحب الإعلان":"الحريف";return `<button class="conversation-item" data-conv="${esc(c.id)}"><div><b>${esc(listingMap[c.listing_id]||"إعلان")}</b><span>${other}</span></div><p>${esc(m?.message||"محادثة جديدة")}</p></button>`;}).join("")}</div>`);
  $$(".conversation-item").forEach(b=>b.addEventListener("click",()=>openMessageBox(b.dataset.conv)));
}

let ratingStats = {};


function adminStatusLabel(status){
  return status==="approved"?"منشور":status==="pending"?"قيد المراجعة":status==="rejected"?"مرفوض":status==="paused"?"متوقف":"منتهي";
}
function reportStatusLabel(status){
  return status==="pending"?"جديد":status==="reviewing"?"قيد المراجعة":status==="resolved"?"تم الحل":"مرفوض";
}

async function adminPanel(section="overview"){
  await loadAdminStatus();
  if(!isAdmin){toast("ما عندكش صلاحية الإدارة.");return;}
  const [{count:pendingCount},{count:reportsCount},{count:usersCount}] = await Promise.all([
    sb.from("listings").select("id",{count:"exact",head:true}).eq("status","pending"),
    sb.from("reports").select("id",{count:"exact",head:true}).eq("status","pending"),
    sb.from("profiles").select("id",{count:"exact",head:true})
  ]);
  const pc=Number(pendingCount||0), rc=Number(reportsCount||0), uc=Number(usersCount||0);
  openModal(`<div class="modal-kicker">إدارة مورد رزق 🛡️</div>
    <h2>لوحة الإدارة</h2>
    <p class="modal-note">من هنا تراجع الإعلانات والبلاغات وتراقب الحسابات.</p>
    <div class="admin-stats">
      <button class="admin-stat ${section==="listings"?"active":""}" id="adminListingsTab"><b>${pc}</b><span>إعلانات تنتظر</span></button>
      <button class="admin-stat ${section==="reports"?"active":""}" id="adminReportsTab"><b>${rc}</b><span>بلاغات جديدة</span></button>
      <button class="admin-stat ${section==="users"?"active":""}" id="adminUsersTab"><b>${uc}</b><span>حسابات</span></button>
      <button class="admin-stat ${section==="promotions"?"active":""}" id="adminPromotionsTab"><b>⭐</b><span>طلبات التمييز</span></button>
    </div>
    <div id="adminContent"><div class="admin-loading">جاري التحميل...</div></div>`);
  $("#adminListingsTab").onclick=()=>adminPanel("listings");
  $("#adminReportsTab").onclick=()=>adminPanel("reports");
  $("#adminUsersTab").onclick=()=>adminPanel("users");
  $("#adminPromotionsTab").onclick=()=>adminPanel("promotions");
  await renderAdminSection(section);
}

async function renderAdminSection(section){
  const box=$("#adminContent"); if(!box)return;
  if(section==="overview"){
    box.innerHTML=`<div class="admin-welcome"><div class="admin-icon">🛡️</div><h3>مرحبا بيك في لوحة الإدارة</h3><p>اختار القسم اللي تحب تراجعه. الإعلانات الجديدة والبلاغات تظهر هنا.</p><div class="admin-quick-actions"><button class="primary-btn" id="quickListings">📋 مراجعة الإعلانات</button><button class="secondary-btn" id="quickReports">🚩 مراجعة البلاغات</button><button class="secondary-btn" id="quickPromotions">⭐ طلبات التمييز</button></div></div>`;
    $("#quickListings").onclick=()=>adminPanel("listings");
    $("#quickReports").onclick=()=>adminPanel("reports");
    $("#quickPromotions").onclick=()=>adminPanel("promotions");
    return;
  }
  if(section==="listings"){
    const {data,error}=await sb.from("listings").select("id,owner_id,listing_type,title,description,category,price,price_label,governorate,delegation,status,is_featured,created_at").order("created_at",{ascending:false}).limit(50);
    if(error){box.innerHTML=`<div class="empty-state"><h3>تعذر تحميل الإعلانات</h3><p>${esc(error.message)}</p></div>`;return;}
    box.innerHTML=(data||[]).length?`<div class="admin-list">${data.map(x=>{
      const price=x.price!=null?`${Number(x.price).toLocaleString("fr-TN")} د.ت`:(x.price_label||"السعر حسب الطلب");
      return `<div class="admin-card">
        <div class="admin-card-top"><span class="tag">${x.listing_type==="product"?"منتج":"خدمة"}</span><span class="my-status">${adminStatusLabel(x.status)}</span></div>
        <h3>${esc(x.title)}</h3><p>${esc((x.description||"").slice(0,180))}</p>
        <div class="listing-meta"><span>📍 ${esc(x.governorate||"غير محدد")}</span><span>💰 ${esc(price)}</span></div>
        <div class="admin-actions">
          ${x.status!=="approved"?`<button class="primary-btn admin-approve" data-id="${esc(x.id)}">✅ نشر</button>`:""}
          ${x.status!=="rejected"?`<button class="danger-btn admin-reject" data-id="${esc(x.id)}">⛔ رفض</button>`:""}
          <button class="secondary-btn admin-feature" data-id="${esc(x.id)}">${x.is_featured?"★ إلغاء التمييز":"⭐ تمييز"}</button>
        </div>
      </div>`;
    }).join("")}</div>`:`<div class="empty-state"><div>📭</div><h3>ما فماش إعلانات</h3><p>الإعلانات الكل مراجَعة حاليا.</p></div>`;
    $$(".admin-approve").forEach(b=>b.onclick=()=>adminUpdateListing(b.dataset.id,"approved"));
    $$(".admin-reject").forEach(b=>b.onclick=()=>adminUpdateListing(b.dataset.id,"rejected"));
    $$(".admin-feature").forEach(b=>b.onclick=()=>adminToggleFeatured(b.dataset.id));
    return;
  }
  if(section==="promotions"){
    const {data,error}=await sb.from("promotions").select("id,user_id,listing_id,promotion_type,price,starts_at,ends_at,status,created_at").eq("promotion_type","featured").order("created_at",{ascending:false}).limit(50);
    if(error){box.innerHTML=`<div class="empty-state"><h3>تعذر تحميل طلبات التمييز</h3><p>${esc(error.message)}</p></div>`;return;}
    const rows=data||[];
    if(!rows.length){box.innerHTML=`<div class="empty-state"><div>⭐</div><h3>ما فماش طلبات تمييز</h3><p>كي يطلب حريف تمييز إعلان، يظهر هنا.</p></div>`;return;}
    const ids=rows.map(x=>x.listing_id).filter(Boolean);
    const lr=ids.length?await sb.from("listings").select("id,title").in("id",ids):{data:[]};
    const lm={};(lr.data||[]).forEach(x=>lm[x.id]=x.title);
    box.innerHTML=`<div class="admin-list">${rows.map(x=>`<div class="admin-card"><div class="admin-card-top"><span class="tag">⭐ تمييز</span><span class="my-status">${x.status==="pending"?"قيد المراجعة":x.status==="active"?"نشط":x.status==="expired"?"منتهي":"ملغى"}</span></div><h3>${esc(lm[x.listing_id]||"إعلان")}</h3><div class="listing-meta"><span>💰 ${Number(x.price||0).toFixed(3)} د.ت</span><span>📅 ${new Date(x.created_at).toLocaleString("fr-TN")}</span></div><div class="admin-actions">${x.status==="pending"?`<button class="primary-btn admin-promo-approve" data-id="${esc(x.id)}" data-listing="${esc(x.listing_id)}" data-days="${x.price==10?30:7}">✅ تفعيل</button><button class="danger-btn admin-promo-reject" data-id="${esc(x.id)}">⛔ رفض</button>`:""}</div></div>`).join("")}</div>`;
    $$(".admin-promo-approve").forEach(b=>b.onclick=()=>adminApprovePromotion(b.dataset.id,b.dataset.listing,Number(b.dataset.days)));
    $$(".admin-promo-reject").forEach(b=>b.onclick=()=>adminRejectPromotion(b.dataset.id));
    return;
  }
  if(section==="reports"){
    const {data,error}=await sb.from("reports").select("id,listing_id,reported_user_id,reason,details,status,created_at").order("created_at",{ascending:false}).limit(50);
    if(error){box.innerHTML=`<div class="empty-state"><h3>تعذر تحميل البلاغات</h3><p>${esc(error.message)}</p></div>`;return;}
    box.innerHTML=(data||[]).length?`<div class="admin-list">${data.map(x=>`<div class="admin-card">
      <div class="admin-card-top"><span class="tag">🚩 إبلاغ</span><span class="my-status">${reportStatusLabel(x.status)}</span></div>
      <h3>${esc(x.reason||"سبب غير محدد")}</h3>
      <p>${esc(x.details||"بدون تفاصيل إضافية")}</p>
      <div class="listing-meta"><span>📅 ${new Date(x.created_at).toLocaleString("fr-TN")}</span></div>
      <div class="admin-actions">
        ${x.status!=="reviewing"?`<button class="secondary-btn admin-report-review" data-id="${esc(x.id)}">🔎 قيد المراجعة</button>`:""}
        ${x.status!=="resolved"?`<button class="primary-btn admin-report-resolve" data-id="${esc(x.id)}">✅ حلّ البلاغ</button>`:""}
        ${x.status!=="rejected"?`<button class="danger-btn admin-report-reject" data-id="${esc(x.id)}">⛔ رفض</button>`:""}
      </div>
    </div>`).join("")}</div>`:`<div class="empty-state"><div>✅</div><h3>ما فماش بلاغات</h3><p>ما وصل حتى بلاغ للإدارة.</p></div>`;
    $$(".admin-report-review").forEach(b=>b.onclick=()=>adminUpdateReport(b.dataset.id,"reviewing"));
    $$(".admin-report-resolve").forEach(b=>b.onclick=()=>adminUpdateReport(b.dataset.id,"resolved"));
    $$(".admin-report-reject").forEach(b=>b.onclick=()=>adminUpdateReport(b.dataset.id,"rejected"));
    return;
  }
  if(section==="users"){
    const {data,error}=await sb.from("profiles").select("id,full_name,account_type,phone,governorate,is_verified,is_blocked,created_at").order("created_at",{ascending:false}).limit(50);
    if(error){box.innerHTML=`<div class="empty-state"><h3>تعذر تحميل الحسابات</h3><p>${esc(error.message)}</p></div>`;return;}
    box.innerHTML=(data||[]).length?`<div class="admin-list">${data.map(x=>`<div class="admin-card">
      <div class="admin-card-top"><span class="tag">${x.account_type==="provider"?"مقدّم خدمة":x.account_type==="seller"?"بائع":"حريف"}</span><span class="my-status">${x.is_blocked?"🚫 محظور":"نشط"}</span></div>
      <h3>${esc(x.full_name||"مستخدم")}</h3>
      <p>${esc(x.governorate||"الموقع غير محدد")} ${x.phone?`• 📱 ${esc(x.phone)}`:""}</p>
      <div class="admin-actions">
        <button class="secondary-btn admin-verify" data-id="${esc(x.id)}" data-value="${x.is_verified?"false":"true"}">${x.is_verified?"✓ إلغاء التوثيق":"✓ توثيق"}</button>
        ${x.id!==currentUser.id?`<button class="${x.is_blocked?"primary-btn":"danger-btn"} admin-block" data-id="${esc(x.id)}" data-value="${x.is_blocked?"false":"true"}">${x.is_blocked?"🔓 فك الحظر":"🚫 حظر"}</button>`:""}
      </div>
    </div>`).join("")}</div>`:`<div class="empty-state"><h3>ما فماش حسابات</h3></div>`;
    $$(".admin-verify").forEach(b=>b.onclick=()=>adminUpdateUser(b.dataset.id,{is_verified:b.dataset.value==="true"},"users"));
    $$(".admin-block").forEach(b=>b.onclick=()=>adminUpdateUser(b.dataset.id,{is_blocked:b.dataset.value==="true"},"users"));
  }
}

async function adminUpdateListing(id,status){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const {error}=await sb.from("listings").update({status,updated_at:new Date().toISOString()}).eq("id",id);
  if(error){toast(error.message||"تعذر تحديث الإعلان.");return;}
  toast(status==="approved"?"تم نشر الإعلان ✅":"تم رفض الإعلان.");
  await adminPanel("listings");
  await loadListings();
}
async function adminToggleFeatured(id){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const {data,error}=await sb.from("listings").select("is_featured").eq("id",id).single();
  if(error||!data){toast("تعذر قراءة الإعلان.");return;}
  const {error:updateError}=await sb.from("listings").update({is_featured:!data.is_featured,updated_at:new Date().toISOString()}).eq("id",id);
  if(updateError){toast(updateError.message||"تعذر تعديل التمييز.");return;}
  toast(data.is_featured?"تم إلغاء التمييز.":"تم تمييز الإعلان ⭐");
  await adminPanel("listings"); await loadListings();
}
async function adminApprovePromotion(id,listingId,days){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const end=new Date(Date.now()+days*86400000).toISOString();
  const p=await sb.from("promotions").update({status:"active",starts_at:new Date().toISOString(),ends_at:end}).eq("id",id);
  if(p.error){toast(p.error.message||"تعذر تفعيل الطلب.");return;}
  const l=await sb.from("listings").update({is_featured:true,featured_until:end,updated_at:new Date().toISOString()}).eq("id",listingId);
  if(l.error){toast(l.error.message||"تم الطلب لكن تعذر تمييز الإعلان.");return;}
  toast("تم تفعيل التمييز ⭐");await adminPanel("promotions");await loadListings();
}
async function adminRejectPromotion(id){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const {error}=await sb.from("promotions").update({status:"cancelled"}).eq("id",id);
  if(error){toast(error.message||"تعذر رفض الطلب.");return;}
  toast("تم رفض طلب التمييز.");await adminPanel("promotions");
}

async function adminUpdateReport(id,status){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const {error}=await sb.from("reports").update({status}).eq("id",id);
  if(error){toast(error.message||"تعذر تحديث البلاغ.");return;}
  toast("تم تحديث حالة البلاغ.");
  await adminPanel("reports");
}
async function adminUpdateUser(id,payload,section="users"){
  await loadAdminStatus(); if(!isAdmin)return toast("ما عندكش صلاحية الإدارة.");
  const {error}=await sb.from("profiles").update(payload).eq("id",id);
  if(error){toast(error.message||"تعذر تحديث الحساب.");return;}
  toast("تم تحديث الحساب.");
  await adminPanel(section);
}

function renderListings(items){
  const grid=$(".listing-grid"); if(!grid)return;
  if(!items.length){grid.innerHTML=`<div class="empty-state"><div>🔎</div><h3>ما لقيناش إعلانات منشورة</h3><p>جرّب كلمة أخرى أو ولاية أخرى. الإعلانات الجديدة تظهر بعد الموافقة.</p></div>`;return;}
  grid.innerHTML=items.map(x=>{
    const initials=(x.title||"م").trim().charAt(0);
    const tag=x.listing_type==="product"?"منتج":"خدمة";
    const price=x.price!=null?`${Number(x.price).toLocaleString("fr-TN")} د.ت`:(x.price_label||"السعر حسب الطلب");
    const stats=ratingStats[x.id]||{avg:0,count:0};
    const ratingText=stats.count?`⭐ ${stats.avg.toFixed(1)} (${stats.count})`:`⭐ ما فماش تقييمات`;
    return `<article class="listing" data-id="${esc(x.id)}"><div class="listing-top"><div class="avatar purple">${esc(initials)}</div>${x.is_featured?'<span class="verified">★ مميّز</span>':''}</div><span class="tag">${tag}</span><h3>${esc(x.title)}</h3><p>${esc(x.description).slice(0,150)}</p><div class="listing-meta"><span>📍 ${esc(x.governorate||"تونس")}</span><span>💰 ${esc(price)}</span></div><div class="rating-summary">${ratingText}</div><div class="listing-actions"><button class="talk-btn" data-owner="${esc(x.owner_id)}" data-listing="${esc(x.id)}">💬 تواصل</button><button class="rate-btn" data-owner="${esc(x.owner_id)}" data-listing="${esc(x.id)}">⭐ قيّم</button><button class="report-btn" data-owner="${esc(x.owner_id)}" data-listing="${esc(x.id)}">🚩 إبلاغ</button></div></article>`;
  }).join("");
  $$(".talk-btn").forEach(b=>b.addEventListener("click",()=>startConversation(b.dataset.listing,b.dataset.owner)));
  $$(".rate-btn").forEach(b=>b.addEventListener("click",()=>openRatingForm(b.dataset.listing,b.dataset.owner)));
  $$(".report-btn").forEach(b=>b.addEventListener("click",()=>openReportForm(b.dataset.listing,b.dataset.owner)));
}

async function loadRatingStats(items){
  ratingStats={};
  const ids=(items||[]).map(x=>x.id).filter(Boolean);
  if(!ids.length)return;
  const {data,error}=await sb.from("ratings").select("listing_id,rating").in("listing_id",ids).eq("status","approved");
  if(error){console.warn("ratings",error);return;}
  (data||[]).forEach(r=>{
    if(!ratingStats[r.listing_id])ratingStats[r.listing_id]={sum:0,count:0,avg:0};
    ratingStats[r.listing_id].sum+=Number(r.rating||0);
    ratingStats[r.listing_id].count+=1;
    ratingStats[r.listing_id].avg=ratingStats[r.listing_id].sum/ratingStats[r.listing_id].count;
  });
}

async function loadListings(){
  if(!sb)return;
  const {data,error}=await sb.from("listings").select("id,owner_id,listing_type,title,description,category,subcategory,price,price_label,governorate,delegation,is_featured,created_at").eq("status","approved").order("is_featured",{ascending:false}).order("created_at",{ascending:false}).limit(30);
  if(error){console.error(error);toast("تعذر تحميل الإعلانات حاليا.");return;}
  currentListings=data||[];
  await loadRatingStats(currentListings);
  renderListings(currentListings);
}

async function openRatingForm(listingId,ownerId){
  if(!currentUser){authForm("login");return;}
  if(currentUser.id===ownerId){toast("ما تنجمش تقيّم إعلانك إنت.");return;}
  const existing=await sb.from("ratings").select("id,rating").eq("listing_id",listingId).eq("reviewer_id",currentUser.id).maybeSingle();
  if(existing.error){toast("تعذر التثبت من التقييم.");return;}
  if(existing.data){toast(`إنت قيّمت الإعلان هذا بـ ${existing.data.rating} ⭐ من قبل.`);return;}
  const listing=currentListings.find(x=>x.id===listingId);
  openModal(`<div class="modal-kicker">تقييم الإعلان ⭐</div><h2>${esc(listing?.title||"الإعلان")}</h2><p class="modal-note">اختار تقييم من نجمة إلى 5 نجوم.</p><div class="star-picker" id="starPicker">${[1,2,3,4,5].map(n=>`<button type="button" class="star-choice" data-rating="${n}" aria-label="${n} نجوم">★</button>`).join("")}</div><p id="ratingHint" class="rating-hint">اضغط على عدد النجوم اللي تحب عليه.</p><button class="primary-btn" id="submitRating" type="button" disabled>إرسال التقييم</button>`);
  let selected=0;
  $$(".star-choice").forEach(b=>b.addEventListener("click",()=>{selected=Number(b.dataset.rating);$$('.star-choice').forEach(s=>s.classList.toggle('selected',Number(s.dataset.rating)<=selected));$('#ratingHint').textContent=`اخترت ${selected} من 5 ⭐`;$('#submitRating').disabled=false;}));
  $("#submitRating").onclick=async()=>{
    if(!selected)return;
    const btn=$("#submitRating");btn.disabled=true;btn.textContent="جاري الحفظ...";
    const {error}=await sb.from("ratings").insert({listing_id:listingId,reviewer_id:currentUser.id,rating:selected,status:"approved"});
    if(error){toast(error.code==="23505"?"إنت قيّمت الإعلان هذا من قبل.":(error.message||"تعذر حفظ التقييم."));btn.disabled=false;btn.textContent="إرسال التقييم";return;}
    toast("يعطيك الصحة على التقييم ⭐");closeModal();await loadListings();
  };
}

async function openReportForm(listingId,ownerId){
  if(!currentUser){authForm("login");return;}
  if(currentUser.id===ownerId){toast("ما تنجمش تعمل إبلاغ على إعلانك إنت.");return;}
  const existing=await sb.from("reports").select("id,status").eq("listing_id",listingId).eq("reporter_id",currentUser.id).limit(1);
  if(existing.error){toast("تعذر التثبت من البلاغات.");return;}
  if(existing.data?.length){toast("سبق وبلّغت على الإعلان هذا. الإدارة باش تراجع البلاغ.");return;}
  const listing=currentListings.find(x=>x.id===listingId);
  openModal(`<div class="modal-kicker">إبلاغ عن إعلان 🚩</div><h2>${esc(listing?.title||"الإعلان")}</h2><p class="modal-note">اختار السبب. البلاغ يوصل للإدارة للمراجعة.</p><form id="reportForm" class="form-grid"><label>سبب الإبلاغ<select name="reason" required><option value="">اختار السبب</option><option value="fraud">احتيال أو محاولة نصب</option><option value="misleading">معلومات مضللة</option><option value="inappropriate">محتوى غير مناسب</option><option value="prohibited">سلعة أو خدمة ممنوعة</option><option value="spam">إعلان مزعج / مكرر</option><option value="other">سبب آخر</option></select></label><label>تفاصيل إضافية <span class="muted">(اختياري)</span><textarea name="details" maxlength="1000" placeholder="فسّر لنا المشكلة إذا تحب..."></textarea></label><button class="primary-btn" type="submit">إرسال البلاغ</button></form>`);
  $("#reportForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(e.target),btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;btn.textContent="جاري الإرسال...";
    const {error}=await sb.from("reports").insert({reporter_id:currentUser.id,listing_id:listingId,reported_user_id:ownerId,reason:fd.get("reason"),details:String(fd.get("details")||"").trim(),status:"pending"});
    if(error){toast(error.code==="23505"?"سبق وبلّغت على الإعلان هذا.":(error.message||"تعذر إرسال البلاغ."));btn.disabled=false;btn.textContent="إرسال البلاغ";return;}
    closeModal();toast("تم إرسال البلاغ للإدارة 🚩");
  });
}

async function startConversation(listingId,ownerId){
  if(!currentUser){authForm("login");return;}
  if(currentUser.id===ownerId){toast("هذا إعلانك إنت.");return;}
  const {data,error}=await sb.from("conversations").select("id").eq("listing_id",listingId).eq("customer_id",currentUser.id).eq("owner_id",ownerId).maybeSingle();
  if(error){toast("تعذر فتح المحادثة.");return;}
  if(data){openMessageBox(data.id);return;}
  const created=await sb.from("conversations").insert({listing_id:listingId,customer_id:currentUser.id,owner_id:ownerId}).select("id").single();
  if(created.error){toast(created.error.message);return;}
  openMessageBox(created.data.id);
}

async function openMessageBox(conversationId){
  openModal(`<div class="modal-kicker">رسالة جديدة 💬</div><h2>تواصل مع صاحب الإعلان</h2><div id="messageHistory" class="message-history"><span>جاري التحميل...</span></div><form id="messageForm" class="message-form"><input name="message" required maxlength="1000" placeholder="اكتب رسالتك..."><button class="primary-btn" type="submit">إرسال</button></form>`);
  const load=async()=>{const {data}=await sb.from("messages").select("id,sender_id,message,created_at").eq("conversation_id",conversationId).order("created_at",{ascending:true});$("#messageHistory").innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender_id===currentUser.id?"mine":"theirs"}">${esc(m.message)}</div>`).join("")||"<span>ابدأ المحادثة 👋</span>";};
  await load();
  $("#messageForm").addEventListener("submit",async e=>{e.preventDefault();const fd=new FormData(e.target),message=fd.get("message");const {error}=await sb.from("messages").insert({conversation_id:conversationId,sender_id:currentUser.id,message});if(error){toast(error.message);return;}e.target.reset();await load();});
}

async function boot(){
  if(!sb){toast("Supabase غير مهيّأ في النسخة الحالية.");return;}
  const {data}=await sb.auth.getSession();
  currentUser=data.session?.user||null;
  await loadProfile();await loadAdminStatus();updateAccountButton();await loadListings();await loadNotificationBadge();
  sb.auth.onAuthStateChange(async (_event,session)=>{currentUser=session?.user||null;await loadProfile();await loadAdminStatus();updateAccountButton();if(_event==="SIGNED_IN"){loadListings();loadNotificationBadge();}else if(_event==="SIGNED_OUT"){isAdmin=false;const b=$("#notificationBadge");if(b){b.hidden=true;b.textContent="0";}}});
}
boot();


// === D17 FEATURE PAYMENT V1 ===
window.D17_FEATURE_PAYMENT = {
  number: "25 723 544",
  name: "Nizar Ajala",
  prices: {7: 3, 30: 10}
};

async function requestFeaturedWithD17(listingId, days){
  if(!currentUser){ authForm("login"); return; }
  days = Number(days);
  const price = days === 30 ? 10 : 3;
  const phone = window.D17_FEATURE_PAYMENT.number;

  openModal(`
    <div class="modal-kicker">⭐ تمييز الإعلان</div>
    <h2>الدفع عبر D17</h2>
    <div class="account-box">
      <b>رقم D17: ${phone}</b>
      <span>المبلغ: ${price.toFixed(3)} د.ت</span>
      <span>المدة: ${days} يوم</span>
    </div>
    <p class="modal-note">حوّل المبلغ عبر D17، وبعدها أدخل رقم/مرجع العملية. التفعيل يتم بعد تأكيد الدفع من الإدارة.</p>
    <input id="d17RefInput" class="text-input" placeholder="رقم أو مرجع عملية D17">
    <button class="primary-btn" id="sendD17Request">📤 إرسال طلب التمييز</button>
    <button class="secondary-btn" onclick="closeModal()">إلغاء</button>
  `);

  $("#sendD17Request").onclick = async ()=>{
    const ref = ($("#d17RefInput")?.value || "").trim();
    if(!ref){ toast("اكتب رقم/مرجع عملية D17."); return; }

    const {error} = await sb.from("promotions").insert({
      user_id: currentUser.id,
      listing_id: listingId,
      promotion_type: "featured",
      price,
      status: "pending",
      starts_at: new Date().toISOString(),
      ends_at: new Date(Date.now()+days*86400000).toISOString()
    });
    if(error){ console.error(error); toast("صار مشكل في إرسال الطلب."); return; }

    // Store payment reference locally for the current browser until a dedicated
    // payment-reference column is added. This does not claim automatic D17 verification.
    localStorage.setItem("d17_ref_"+listingId, ref);
    closeModal();
    toast("تم إرسال طلب التمييز. نستناو تأكيد الدفع من الإدارة.");
    try { await myListings(); } catch(e) {}
  };
}

window.requestFeaturedWithD17 = requestFeaturedWithD17;
