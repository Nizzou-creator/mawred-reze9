package com.mawredrezq.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    private static final String HOME_URL =
        "https://nizzou-creator.github.io/mawred-reze9/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                // Hide the website's APK download button while running inside the Android app.
                view.evaluateJavascript(
                    "(function(){" +
                    "function hideAppButton(){" +
                    "var b=document.getElementById('app-download-button');" +
                    "if(b){b.remove();}" +
                    "}" +
                    "hideAppButton();" +
                    "new MutationObserver(hideAppButton).observe(document.documentElement,{childList:true,subtree:true});" +
                    "setTimeout(hideAppButton,500);" +
                    "setTimeout(hideAppButton,1500);" +
                    "})();",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(HOME_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
