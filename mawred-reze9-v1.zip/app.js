const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

const toast = (message) => {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
};

$("#menuBtn")?.addEventListener("click", () => {
  $("#mainNav")?.classList.toggle("open");
});

$$("nav a").forEach(link => {
  link.addEventListener("click", () => $("#mainNav")?.classList.remove("open"));
});

function runSearch(term = null) {
  const input = $("#searchInput");
  if (term) input.value = term;
  const q = input.value.trim();
  const location = $("#locationSelect").value;

  if (!q && !location) {
    toast("اكتب شنوّة تلوج واختار المنطقة إذا تحب.");
    $("#search").scrollIntoView({ behavior: "smooth" });
    return;
  }

  const where = location ? ` في ${location}` : "";
  toast(`نبحثولك على "${q || "إعلانات"}"${where}...`);
  document.querySelector(".featured-section")?.scrollIntoView({ behavior: "smooth" });
}

$("#searchBtn")?.addEventListener("click", () => runSearch());
$("#searchInput")?.addEventListener("keydown", e => {
  if (e.key === "Enter") runSearch();
});

$$("[data-search]").forEach(btn => {
  btn.addEventListener("click", () => runSearch(btn.dataset.search));
});

function requireAccount(message = "باش تستعمل الخاصية هاذي، يلزمك تعمل حساب.") {
  toast(message);
}

$("#publishBtn")?.addEventListener("click", () => {
  requireAccount("النشر مجاني. إنشاء الحساب باش نكملولك الخطوة الجاية.");
  setTimeout(() => $("#account")?.scrollIntoView({ behavior: "smooth" }), 500);
});

$("#messagesBtn")?.addEventListener("click", () => {
  requireAccount("سجّل دخولك باش تشوف رسائلك.");
});

$("#registerBtn")?.addEventListener("click", () => {
  toast("التسجيل المجاني باش يكون مربوط بـ Supabase في المرحلة الجاية.");
});

$("#allListingsBtn")?.addEventListener("click", () => {
  toast("قسم الإعلانات الكاملة باش يتربط بقاعدة البيانات.");
});

$$(".contact-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    requireAccount("يلزمك حساب باش تتواصل مع صاحب الإعلان.");
  });
});
