// إعدادات المشروع
// لا تضع هنا أي Service Role Key أو كلمة سر.
// المفتاح العام لـ Supabase يمكن إضافته لاحقًا بعد إنشاء مشروع Supabase الخاص بـ "مورد رزق".

window.APP_CONFIG = {
  appName: "مورد رزق",
  supabaseUrl: "",
  supabasePublishableKey: ""
};
