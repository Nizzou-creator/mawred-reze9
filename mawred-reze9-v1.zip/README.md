# مورد رزق 🇹🇳

منصة تونسية تجمع الحرفاء، مقدمي الخدمات والبائعين.

## النسخة الحالية
هذه V1 واجهة جاهزة ومتجاوبة للهاتف والكمبيوتر، وتشمل:
- الرئيسية
- البحث
- الخدمات
- المنتجات
- مقدمي الخدمات
- البائعين
- الإعلانات المميزة
- الرسائل
- الحساب
- النشر
- أساس جاهز للربط مع Supabase

## الخطة التقنية
- Frontend: HTML + CSS + JavaScript
- Backend: Supabase
- Authentication: Supabase Auth
- Database: PostgreSQL عبر Supabase
- Messaging: Supabase Realtime
- Notifications: داخل التطبيق، ثم Push لاحقًا
- Hosting: GitHub Pages أو أي استضافة Static

## مهم
لا تضع Service Role Key أو أي مفتاح سري داخل GitHub.
يتم إضافة بيانات Supabase العامة فقط بعد إنشاء مشروع Supabase الخاص بمورد رزق.

## GitHub Pages
ملف workflow موجود في:
`.github/workflows/deploy.yml`
وهو يقوم بنشر الموقع تلقائيًا على GitHub Pages بعد كل Push إلى `main`.
